package com.akfinance.data

import java.time.LocalDate
import java.util.UUID

enum class TransactionType { INCOME, EXPENSE }

data class Transaction(
    val id: String = UUID.randomUUID().toString(),
    val date: String = LocalDate.now().toString(),
    val type: TransactionType,
    val category: String,
    val amount: Long,
    val note: String = ""
)

data class FinanceSummary(val balance: Long, val income: Long, val expense: Long)
