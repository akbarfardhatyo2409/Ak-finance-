package com.akfinance

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Analytics
import androidx.compose.material.icons.filled.ArrowDownward
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.AttachMoney
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.InsertDriveFile
import androidx.compose.material.icons.filled.ReceiptLong
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.akfinance.data.Transaction
import com.akfinance.data.TransactionType
import com.akfinance.data.XlsxStore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.NumberFormat
import java.time.LocalDate
import java.util.Locale

private val Navy = Color(0xFF101C2B)
private val Panel = Color(0xFF1A2A3B)
private val Green = Color(0xFF4BD3A0)
private val Red = Color(0xFFFF8290)
private val Background = Color(0xFFF4F7FA)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { AKFinanceApp() }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun AKFinanceApp() {
    val context = androidx.compose.ui.platform.LocalContext.current
    val scope = rememberCoroutineScope()
    var fileUri by remember { mutableStateOf<Uri?>(null) }
    var fileName by remember { mutableStateOf("Belum ada spreadsheet") }
    var transactions by remember { mutableStateOf<List<Transaction>>(emptyList()) }
    var selectedTab by remember { mutableIntStateOf(0) }
    var showAdd by remember { mutableStateOf(false) }
    var notice by remember { mutableStateOf<String?>(null) }
    var busy by remember { mutableStateOf(false) }

    fun load(uri: Uri) {
        scope.launch {
            busy = true
            runCatching { withContext(Dispatchers.IO) { XlsxStore.read(context.contentResolver, uri) } }
                .onSuccess { transactions = it; fileUri = uri; fileName = uri.lastPathSegment ?: "AKFinance.xlsx"; notice = "Spreadsheet berhasil dibuka" }
                .onFailure { notice = "Gagal membaca Excel: ${it.message}" }
            busy = false
        }
    }
    val openPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        uri?.let { runCatching { context.contentResolver.takePersistableUriPermission(it, Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION) }; load(it) }
    }
    val createPicker = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")) { uri ->
        uri?.let { target ->
            runCatching { context.contentResolver.takePersistableUriPermission(target, Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION) }
            scope.launch {
                busy = true
                runCatching { withContext(Dispatchers.IO) { XlsxStore.create(context.contentResolver, target) } }
                    .onSuccess { fileUri = target; fileName = target.lastPathSegment ?: "AKFinance.xlsx"; transactions = emptyList(); notice = "Spreadsheet AK Finance dibuat" }
                    .onFailure { notice = "Gagal membuat file: ${it.message}" }
                busy = false
            }
        }
    }

    fun persist(updated: List<Transaction>) {
        val uri = fileUri
        if (uri == null) { notice = "Buat atau buka spreadsheet terlebih dahulu"; return }
        scope.launch {
            busy = true
            runCatching { withContext(Dispatchers.IO) { XlsxStore.write(context.contentResolver, uri, updated) } }
                .onSuccess { transactions = updated; notice = "Perubahan tersimpan ke Excel" }
                .onFailure { notice = "Gagal menyimpan. Data di layar dipertahankan: ${it.message}" }
            busy = false
        }
    }

    MaterialTheme(colorScheme = lightColorScheme(primary = Navy, secondary = Green, background = Background)) {
        Scaffold(
            containerColor = Background,
            topBar = {
                TopAppBar(
                    title = { Column { Text("AK Finance", fontWeight = FontWeight.Bold); Text("PERSONAL FINANCE", fontSize = 10.sp, letterSpacing = 1.5.sp, color = MaterialTheme.colorScheme.onSurfaceVariant) } },
                    actions = { IconButton(onClick = { openPicker.launch(arrayOf("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", "application/octet-stream")) }) { Icon(Icons.Default.InsertDriveFile, "Buka Excel") } },
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = Background)
                )
            },
            bottomBar = {
                NavigationBar(containerColor = Color.White) {
                    NavigationBarItem(selected = selectedTab == 0, onClick = { selectedTab = 0 }, icon = { Icon(Icons.Default.Home, null) }, label = { Text("Beranda") })
                    NavigationBarItem(selected = selectedTab == 1, onClick = { selectedTab = 1 }, icon = { Icon(Icons.Default.ReceiptLong, null) }, label = { Text("Transaksi") })
                    NavigationBarItem(selected = selectedTab == 2, onClick = { selectedTab = 2 }, icon = { Icon(Icons.Default.Analytics, null) }, label = { Text("Analitik") })
                }
            },
            floatingActionButton = { FloatingActionButton(onClick = { showAdd = true }, containerColor = Navy, contentColor = Color.White) { Icon(Icons.Default.Add, "Tambah transaksi") } },
            snackbarHost = { SnackbarHost(hostState = remember { SnackbarHostState() }) }
        ) { padding ->
            Column(Modifier.padding(padding).fillMaxSize()) {
                if (busy) LinearProgressIndicator(Modifier.fillMaxWidth(), color = Green)
                when (selectedTab) {
                    0 -> Dashboard(transactions, fileName, onCreate = { createPicker.launch("AKFinance.xlsx") }, onOpen = { openPicker.launch(arrayOf("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", "application/octet-stream")) }, onTransactions = { selectedTab = 1 })
                    1 -> TransactionList(transactions, onDelete = { t -> persist(transactions.filterNot { it.id == t.id }) })
                    else -> AnalyticsScreen(transactions)
                }
                notice?.let { msg -> Text(msg, Modifier.fillMaxWidth().clickable { notice = null }.padding(horizontal = 16.dp, vertical = 6.dp), color = Navy, fontSize = 12.sp) }
            }
            if (showAdd) AddTransactionDialog(onDismiss = { showAdd = false }, onSave = { item -> if (fileUri == null) { notice = "Buat atau buka spreadsheet terlebih dahulu" } else { showAdd = false; persist(transactions + item) } })
        }
    }
}

@Composable
private fun Dashboard(items: List<Transaction>, fileName: String, onCreate: () -> Unit, onOpen: () -> Unit, onTransactions: () -> Unit) {
    val income = items.filter { it.type == TransactionType.INCOME }.sumOf { it.amount }
    val expense = items.filter { it.type == TransactionType.EXPENSE }.sumOf { it.amount }
    val balance = income - expense
    LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        item {
            Column(Modifier.fillMaxWidth().background(Navy, RoundedCornerShape(24.dp)).padding(20.dp)) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Text("TOTAL SALDO", color = Color(0xFFB6C5D3), fontSize = 11.sp, letterSpacing = 1.4.sp)
                    Icon(Icons.Default.AttachMoney, null, tint = Green)
                }
                Spacer(Modifier.height(8.dp)); Text(rupiah(balance), color = Color.White, fontSize = 30.sp, fontWeight = FontWeight.Bold)
                Text("Berdasarkan seluruh transaksi", color = Color(0xFFB6C5D3), fontSize = 12.sp)
                Spacer(Modifier.height(22.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    SummaryTile("Pemasukan", income, Green, Modifier.weight(1f), true)
                    SummaryTile("Pengeluaran", expense, Red, Modifier.weight(1f), false)
                }
            }
        }
        item {
            Text("Spreadsheet", fontSize = 18.sp, fontWeight = FontWeight.Bold)
            Row(Modifier.fillMaxWidth().background(Color.White, RoundedCornerShape(16.dp)).padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.InsertDriveFile, null, tint = Green, modifier = Modifier.size(30.dp))
                Spacer(Modifier.width(10.dp)); Column(Modifier.weight(1f)) { Text(fileName, fontWeight = FontWeight.SemiBold, maxLines = 1); Text("Penyimpanan lokal .xlsx", color = Color.Gray, fontSize = 11.sp) }
            }
            Spacer(Modifier.height(10.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedButton(onClick = onOpen, modifier = Modifier.weight(1f)) { Text("Buka file") }
                Button(onClick = onCreate, modifier = Modifier.weight(1f), colors = ButtonDefaults.buttonColors(containerColor = Navy)) { Text("Buat Excel") }
            }
        }
        item { Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) { Text("Transaksi terbaru", fontSize = 18.sp, fontWeight = FontWeight.Bold); Text("Lihat semua", color = Green, modifier = Modifier.clickable(onClick = onTransactions), fontSize = 12.sp) } }
        if (items.isEmpty()) item { EmptyState("Belum ada transaksi", "Buat atau buka spreadsheet, lalu tambahkan transaksi.") }
        items(items.sortedByDescending { it.date }.take(5), key = { it.id }) { TransactionRow(it) }
    }
}

@Composable
private fun SummaryTile(title: String, amount: Long, color: Color, modifier: Modifier, positive: Boolean) {
    Column(modifier.background(Panel, RoundedCornerShape(14.dp)).padding(12.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) { Icon(if (positive) Icons.Default.ArrowDownward else Icons.Default.ArrowUpward, null, tint = color, modifier = Modifier.size(15.dp)); Spacer(Modifier.width(5.dp)); Text(title, color = Color(0xFFD3DCE5), fontSize = 11.sp) }
        Spacer(Modifier.height(6.dp)); Text(rupiah(amount), color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun TransactionList(items: List<Transaction>, onDelete: (Transaction) -> Unit) {
    LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item { Text("Semua transaksi", fontSize = 22.sp, fontWeight = FontWeight.Bold); Text("${items.size} catatan tersimpan", color = Color.Gray, fontSize = 12.sp) }
        if (items.isEmpty()) item { EmptyState("Belum ada transaksi", "Transaksi yang kamu tambahkan akan muncul di sini.") }
        items(items.sortedByDescending { it.date }, key = { it.id }) { item ->
            Row(Modifier.fillMaxWidth().background(Color.White, RoundedCornerShape(15.dp)).padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(40.dp).background(if (item.type == TransactionType.INCOME) Color(0xFFE4F8F0) else Color(0xFFFFEBED), RoundedCornerShape(12.dp)), contentAlignment = Alignment.Center) { Icon(if (item.type == TransactionType.INCOME) Icons.Default.ArrowDownward else Icons.Default.ArrowUpward, null, tint = if (item.type == TransactionType.INCOME) Color(0xFF16885D) else Red) }
                Spacer(Modifier.width(12.dp)); Column(Modifier.weight(1f)) { Text(item.category, fontWeight = FontWeight.SemiBold); Text("${item.date} • ${item.note}", color = Color.Gray, fontSize = 11.sp, maxLines = 1) }
                Column(horizontalAlignment = Alignment.End) { Text((if (item.type == TransactionType.INCOME) "+" else "−") + rupiah(item.amount), color = if (item.type == TransactionType.INCOME) Color(0xFF16885D) else Red, fontWeight = FontWeight.Bold, fontSize = 12.sp); IconButton(onClick = { onDelete(item) }, modifier = Modifier.size(28.dp)) { Icon(Icons.Default.Delete, "Hapus", tint = Color.Gray, modifier = Modifier.size(17.dp)) } }
            }
        }
    }
}

@Composable
private fun AnalyticsScreen(items: List<Transaction>) {
    val income = items.filter { it.type == TransactionType.INCOME }.sumOf { it.amount }
    val expense = items.filter { it.type == TransactionType.EXPENSE }.sumOf { it.amount }
    Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text("Analitik keuangan", fontSize = 22.sp, fontWeight = FontWeight.Bold)
        Text("Ringkasan berdasarkan seluruh data spreadsheet", color = Color.Gray, fontSize = 12.sp)
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) { MetricCard("Pemasukan", income, Green, Modifier.weight(1f)); MetricCard("Pengeluaran", expense, Red, Modifier.weight(1f)) }
        Text("Komposisi", fontWeight = FontWeight.Bold, fontSize = 17.sp)
        val total = (income + expense).coerceAtLeast(1)
        Row(Modifier.fillMaxWidth().height(14.dp).background(Color(0xFFE5EAF0), RoundedCornerShape(20.dp))) {
            Box(Modifier.weight(income.toFloat().coerceAtLeast(0.001f)).fillMaxHeight().background(Green))
            Box(Modifier.weight(expense.toFloat().coerceAtLeast(0.001f)).fillMaxHeight().background(Red))
        }
        Text("Pemasukan ${(income * 100 / total)}%  •  Pengeluaran ${(expense * 100 / total)}%", color = Color.Gray, fontSize = 12.sp)
        Text("Kategori", fontWeight = FontWeight.Bold, fontSize = 17.sp)
        items.groupBy { it.category }.entries.sortedByDescending { e -> e.value.sumOf { it.amount } }.forEach { (category, rows) ->
            val value = rows.sumOf { it.amount }
            Row(Modifier.fillMaxWidth().background(Color.White, RoundedCornerShape(12.dp)).padding(14.dp), horizontalArrangement = Arrangement.SpaceBetween) { Text(category); Text(rupiah(value), fontWeight = FontWeight.SemiBold) }
        }
    }
}

@Composable
private fun MetricCard(title: String, value: Long, color: Color, modifier: Modifier) {
    Column(modifier.background(Color.White, RoundedCornerShape(16.dp)).padding(14.dp)) { Text(title, color = Color.Gray, fontSize = 12.sp); Text(rupiah(value), color = color, fontWeight = FontWeight.Bold, fontSize = 17.sp) }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun AddTransactionDialog(onDismiss: () -> Unit, onSave: (Transaction) -> Unit) {
    var type by remember { mutableStateOf(TransactionType.EXPENSE) }
    var amount by remember { mutableStateOf("") }
    var category by remember { mutableStateOf("Makanan") }
    var note by remember { mutableStateOf("") }
    var date by remember { mutableStateOf(LocalDate.now().toString()) }
    val categories = if (type == TransactionType.INCOME) listOf("Gaji", "Bisnis", "Hadiah", "Investasi", "Lainnya") else listOf("Makanan", "Transportasi", "Belanja", "Pendidikan", "Tagihan", "Hiburan", "Lainnya")
    AlertDialog(onDismissRequest = onDismiss, title = { Text("Tambah transaksi", fontWeight = FontWeight.Bold) }, text = {
        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(selected = type == TransactionType.INCOME, onClick = { type = TransactionType.INCOME; category = "Gaji" }, label = { Text("Pemasukan") })
                FilterChip(selected = type == TransactionType.EXPENSE, onClick = { type = TransactionType.EXPENSE; category = "Makanan" }, label = { Text("Pengeluaran") })
            }
            OutlinedTextField(value = amount, onValueChange = { amount = it.filter(Char::isDigit) }, label = { Text("Nominal (Rp)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), singleLine = true)
            var expanded by remember { mutableStateOf(false) }
            ExposedDropdownMenuBox(expanded = expanded, onExpandedChange = { expanded = it }) {
                OutlinedTextField(value = category, onValueChange = {}, readOnly = true, label = { Text("Kategori") }, trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded) }, modifier = Modifier.menuAnchor().fillMaxWidth())
                ExposedDropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) { categories.forEach { c -> DropdownMenuItem(text = { Text(c) }, onClick = { category = c; expanded = false }) } }
            }
            OutlinedTextField(value = date, onValueChange = { date = it }, label = { Text("Tanggal (YYYY-MM-DD)") }, singleLine = true)
            OutlinedTextField(value = note, onValueChange = { note = it }, label = { Text("Catatan (opsional)") }, singleLine = true)
        }
    }, confirmButton = { Button(onClick = { val n = amount.toLongOrNull(); if (n != null && n > 0 && runCatching { LocalDate.parse(date) }.isSuccess) onSave(Transaction(date = date, type = type, category = category, amount = n, note = note.trim())) }, colors = ButtonDefaults.buttonColors(containerColor = Navy)) { Text("Simpan") } }, dismissButton = { TextButton(onClick = onDismiss) { Text("Batal") } })
}

@Composable
private fun TransactionRow(item: Transaction) {
    Row(Modifier.fillMaxWidth().background(Color.White, RoundedCornerShape(14.dp)).padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
        Icon(if (item.type == TransactionType.INCOME) Icons.Default.ArrowDownward else Icons.Default.ArrowUpward, null, tint = if (item.type == TransactionType.INCOME) Green else Red)
        Spacer(Modifier.width(10.dp)); Column(Modifier.weight(1f)) { Text(item.category, fontWeight = FontWeight.SemiBold); Text(item.date, color = Color.Gray, fontSize = 11.sp) }
        Text((if (item.type == TransactionType.INCOME) "+" else "−") + rupiah(item.amount), fontWeight = FontWeight.Bold, color = if (item.type == TransactionType.INCOME) Color(0xFF16885D) else Red, fontSize = 12.sp)
    }
}

@Composable
private fun EmptyState(title: String, subtitle: String) { Column(Modifier.fillMaxWidth().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) { Icon(Icons.Default.ReceiptLong, null, tint = Color.LightGray, modifier = Modifier.size(42.dp)); Spacer(Modifier.height(8.dp)); Text(title, fontWeight = FontWeight.SemiBold); Text(subtitle, color = Color.Gray, fontSize = 12.sp) } }
private fun rupiah(value: Long): String = NumberFormat.getCurrencyInstance(Locale("id", "ID")).apply { maximumFractionDigits = 0 }.format(value)
