package com.akfinance.data

import android.content.ContentResolver
import android.net.Uri
import android.util.Xml
import org.xmlpull.v1.XmlPullParser
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

/**
 * Lightweight XLSX codec for AK Finance's own workbook template.
 * It deliberately uses Android's built-in ZIP/XML APIs, so no network or server is needed.
 * Workbook layout: Transactions sheet with columns ID, Date, Type, Category, Amount, Note.
 */
object XlsxStore {
    private const val MIME = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
    private const val HEADER = "ID|Date|Type|Category|Amount|Note"

    fun create(resolver: ContentResolver, uri: Uri) {
        write(resolver, uri, emptyList())
    }

    fun read(resolver: ContentResolver, uri: Uri): List<Transaction> {
        val input = resolver.openInputStream(uri) ?: error("Tidak dapat membuka file Excel")
        val entries = mutableMapOf<String, ByteArray>()
        ZipInputStream(input).use { zip ->
            var e = zip.nextEntry
            while (e != null) {
                if (!e.isDirectory) entries[e.name] = zip.readBytes()
                zip.closeEntry(); e = zip.nextEntry
            }
        }
        val sheet = entries["xl/worksheets/sheet1.xml"] ?: return emptyList()
        val shared = parseSharedStrings(entries["xl/sharedStrings.xml"])
        return parseRows(sheet, shared).drop(1).mapNotNull { row ->
            if (row.size < 5) return@mapNotNull null
            runCatching {
                Transaction(
                    id = row.getOrElse(0) { "" },
                    date = row.getOrElse(1) { "" },
                    type = if (row.getOrElse(2) { "EXPENSE" }.equals("INCOME", true)) TransactionType.INCOME else TransactionType.EXPENSE,
                    category = row.getOrElse(3) { "Lainnya" },
                    amount = row.getOrElse(4) { "0" }.toDouble().toLong(),
                    note = row.getOrElse(5) { "" }
                )
            }.getOrNull()
        }
    }

    fun write(resolver: ContentResolver, uri: Uri, transactions: List<Transaction>) {
        val output = resolver.openOutputStream(uri, "wt") ?: error("Tidak dapat menulis file Excel")
        val rows = listOf(listOf("ID", "Date", "Type", "Category", "Amount", "Note")) + transactions.map {
            listOf(it.id, it.date, it.type.name, it.category, it.amount.toString(), it.note)
        }
        ZipOutputStream(output).use { zip ->
            fun entry(name: String, content: String) {
                zip.putNextEntry(ZipEntry(name)); zip.write(content.toByteArray(Charsets.UTF_8)); zip.closeEntry()
            }
            entry("[Content_Types].xml", """<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/><Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/></Types>""")
            entry("_rels/.rels", """<?xml version="1.0" encoding="UTF-8"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>""")
            entry("xl/workbook.xml", """<?xml version="1.0" encoding="UTF-8"?><workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets><sheet name="Transactions" sheetId="1" r:id="rId1"/></sheets></workbook>""")
            entry("xl/_rels/workbook.xml.rels", """<?xml version="1.0" encoding="UTF-8"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/></Relationships>""")
            val xml = buildString {
                append("<?xml version=\"1.0\" encoding=\"UTF-8\"?><worksheet xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\"><sheetData>")
                rows.forEachIndexed { ri, row ->
                    append("<row r=\"${ri + 1}\">")
                    row.forEachIndexed { ci, value ->
                        val ref = columnName(ci + 1) + (ri + 1)
                        append("<c r=\"$ref\" t=\"inlineStr\"><is><t xml:space=\"preserve\">${escapeXml(value)}</t></is></c>")
                    }
                    append("</row>")
                }
                append("</sheetData></worksheet>")
            }
            entry("xl/worksheets/sheet1.xml", xml)
        }
    }

    private fun parseSharedStrings(bytes: ByteArray?): List<String> {
        if (bytes == null) return emptyList()
        val p = Xml.newPullParser(); p.setInput(ByteArrayInputStream(bytes), "UTF-8")
        val out = mutableListOf<String>(); var inSi = false; var current = StringBuilder()
        var event = p.eventType
        while (event != XmlPullParser.END_DOCUMENT) {
            if (event == XmlPullParser.START_TAG && p.name == "si") { inSi = true; current = StringBuilder() }
            else if (event == XmlPullParser.START_TAG && p.name == "t" && inSi) current.append(p.nextText())
            else if (event == XmlPullParser.END_TAG && p.name == "si") { out += current.toString(); inSi = false }
            event = p.next()
        }
        return out
    }

    private fun parseRows(bytes: ByteArray, shared: List<String>): List<List<String>> {
        val p = Xml.newPullParser(); p.setInput(ByteArrayInputStream(bytes), "UTF-8")
        val rows = mutableListOf<List<String>>(); var row: MutableList<String>? = null
        var cellType = ""; var cellValue = ""; var inValue = false; var event = p.eventType
        while (event != XmlPullParser.END_DOCUMENT) {
            when (event) {
                XmlPullParser.START_TAG -> when (p.name) {
                    "row" -> row = mutableListOf()
                    "c" -> { cellType = p.getAttributeValue(null, "t") ?: ""; cellValue = "" }
                    "v", "t" -> if (row != null) { inValue = true; cellValue = p.nextText(); inValue = false; row?.add(if (cellType == "s") shared.getOrElse(cellValue.toIntOrNull() ?: -1) { "" } else cellValue) }
                }
                XmlPullParser.END_TAG -> if (p.name == "row" && row != null) { rows += row!!.toList(); row = null }
            }
            event = p.next()
        }
        return rows
    }

    private fun columnName(number: Int): String {
        var n = number; val result = StringBuilder()
        while (n > 0) { val rem = (n - 1) % 26; result.insert(0, ('A'.code + rem).toChar()); n = (n - 1) / 26 }
        return result.toString()
    }
    private fun escapeXml(s: String) = s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace("\"", "&quot;").replace("'", "&apos;")
}
